Tile map taken from: https://cainos.itch.io/pixel-art-top-down-basic
Note from creator:
    "LICENCE:
    This asset pack can be used in both free and commercial projects. You can modify it to suit your own needs. Credit is not needed but appreciated.  You may not redistribute it or resell it."

Basic player movement tutorial: https://www.youtube.com/watch?v=-4jEXTwTsVI&list=WL&index=5&t=1036s

Picked Coin Echo by NenadSimic -- https://freesound.org/s/171696/ -- License: Attribution 4.0

cat meow by tuberatanka -- https://freesound.org/s/110011/ -- License: Creative Commons 0